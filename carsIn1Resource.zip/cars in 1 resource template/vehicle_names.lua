function AddTextEntry(key, value)

Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), key, value)

end

Citizen.CreateThread(function()

-- Helicopters -- 
AddTextEntry('md902', 'London Air Ambulance')

-- Audi -- 

end)

-- rename vehicles here and changes will reflect in game. faster way than changing all the file names.